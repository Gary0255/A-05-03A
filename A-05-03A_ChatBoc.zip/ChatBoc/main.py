# import library
import cv2
import random
import time
# import data base
import database_rex as data


# create customer class to store it's property
class Customer(object):
    def __init__(self):
        # create customer variable
        self.surname = None
        self.delv = None
        self.add = None
        self.phone = None
        self.name = None
        self.shop = None
        self.shop_list = []
        self.time = None
        self.counter = 0
        self.card = None
        self.reminder = None
        self.feedback = None

    # as a function to ask delivery(yes)/pick up(no)
    def get_delivery(self):
        # as a counter just run one time
        if self.counter == 0:
            print("Rex Bot: Alright. May I know whether you want to pick up or delivery the food?")
            user_input = input()
            if user_input == "pick up":
                self.delv = "no"
            else:
                self.delv = "yes"
            self.counter += 1

    # as a function to ask name, phone, address(delivery)
    def get_info(self):
        # as a counter just run one time
        if self.counter == 1:
            while True:
                print("Rex Bot: Alright, can I get your information?")
                user_input = input()
                if user_input == "yes":
                    print("Rex Bot: Can I get your name, please?")
                    self.name = input()
                    print(f"Rex Bot: Ok {customer.surname}, may I get your phone number?")
                    self.phone = input()

                    if self.delv == "yes":
                        print("Rex Bot: Please enter your address: ")
                        self.add = input()
                    else:
                        self.add = None

                    break
                else:
                    print("Rex Bot: Sorry to stop you here but we need your informations to proceed the order.")
                    continue
            self.counter += 1

    # as a function to find out the stall that have placed orders before
    def get_shop_list(self):
        list = [mamak, malay, beverage, korean, japanese]

        for i in list:
            if i.order_list:
                self.shop_list.append(i)

    # as a function to get time when customer received food
    def get_time(self):
        print("Rex Bot: Noted sir. May I know do you want to order for now or later")
        user_input = input()
        if user_input == "now":
            self.time = "now"
            print("Rex Bot: Ok sir. We will prepare the food now.")
        else:
            print("Rex Bot: Sure. May I know when do you want to get the food? *(9.00 am)")
            user_input = input()
            self.time = user_input
            print(f"Rex Bot: Ok sir. The food will be ready by {self.time}.")

    # as a function to identity customer have discount anot
    def get_card(self):
        print("Rex Bot: Are you university student/lecture/staff or not")
        user_input = input()
        if user_input == "yes":
            self.card = "yes"
            print("Rex Bot: Please insert the university card ID")
            input()
            print("Rex Bot: Identifying ID...")
            time.sleep(1)
            print("Rex Bot: Verify successfully. You are offered 5% discount.")
            time.sleep(1)
        else:
            self.card = "no"

    # as a function to get remimder from customer
    def get_reminder(self):
        print("Rex Bot: Do you have any reminder or special instruction (got any allergy)? ")
        user_input = input()
        if user_input == "no":
            pass
        elif user_input:
            print(f"Rex Bot: OK sir,let me confirm the reminder with you. {user_input}")
            self.reminder = user_input

    # as a function to get feedback from customer
    def get_feedback(self):
        print("Rex Bot: Sir, before you go, please give some feedbacks on our services: ")
        user_input = input()
        if user_input == "no":
            pass
        elif user_input:
            print("Rex Bot: Thank you for your feedback, sir.")
            self.feedback = user_input

# create restaurant class
class Restaurant(object):
    def __init__(self, name):
        self.name = name
        self.menu = {}
        self.order_list = {}

    # add food into menu
    def add_menu(self, name, food):
        self.menu[name] = food

    # add food to menu
    def add_food(self, stall):
        for i in stall:
            food = Food(i["item"], i["price"], i["del_serv"])
            self.add_menu(i["item"].lower(), food)

    # add food and quantity to the order list
    def add_order_list(self, food, quantity, delv):
        food = food.lower()
        flat = self.judge_delv(food, delv)
        # when true
        if flat == True:
            if food not in self.order_list:
                self.order_list[food] = quantity
                self.menu[food].quantity = quantity
            else:
                self.order_list[food] += quantity
                self.menu[food].quantity += quantity
        # when input food error
        else:
            print(f"Food error!! --> {flat} --> {food}")
            if flat == "Do not offer delivery service":
                print("Sorry to inform that this food does not have delivery service")
            elif flat == "Do not exist in menu":
                print("Oops, I think you are ordering the unavailable food")
            print("Rex Bot: Do you want add on any food?")
            ans = input()
            if ans == "yes":
                print("Rex Bot: Please insert the food : eg.(5 ayam goreng, 4 nasi lemak)")
                receive_order()

    # to judge input have error anot
    def judge_delv(self, food, delv):
        if food in self.menu:
            if delv == "yes":
                if self.menu[f"{food}"].deliv == "yes":
                    return True
                else:
                    return "Do not offer delivery service"
            else:
                return True
        else:
            return "Do not exist in menu"

    # to remove food(quantity) from order list
    def remove_food(self, food, quantity):
        if food in self.order_list:
            self.order_list[food] -= quantity
            if self.order_list[food] == 0:
                self.order_list.pop(food)
        else:
            food = food.title()
            print(f"{food} does not exist in order list")

    # to print out menu exist in current restaurant
    def print_menu(self):
        print('*' * 12)
        print("* {0:^8s} *".format(self.name))
        print('*' * 12)
        print("# " * 27)
        print("#{0:^25s}#{1:^14s}#{2:^10s}#".format("Name", "Price", "Delivery"))
        print("# " * 27)
        for i in self.menu.values():
            print("# ", i, " #")
        else:
            print("# " * 27)
            print()

# create food class
class Food(object):
    # initialize the food properties
    def __init__(self, name, price, yes, quantity=0):
        self.name = name
        self.price = price
        self.deliv = yes
        self.quantity = quantity

    # print out food format
    def __str__(self):
        return ("{0:<25s}{1:<12s}{2:^10s}".format(self.name, ("  RM" + self.price), self.deliv))


# create restaurant object
malay = Restaurant("Malay")
mamak = Restaurant("Mamak")
beverage = Restaurant("Beverage")
korean = Restaurant("Korean")
japanese = Restaurant("Japanese")

# create food object and add into menu
malay.add_food(data.malay)
mamak.add_food(data.mamak)
beverage.add_food(data.beverage)
korean.add_food(data.Korean)
japanese.add_food(data.Japanese)

# receive customer order
def receive_order():
    try:
        # *(5 ayam goreng, 4 nasi lemak)
        list = input()
        list = list.split(",") #["5 ayam goreng"," 4 nasi lemak"]
        for i in range(len(list)):
            food = "" # as a variable to store food
            n = list[i].strip() # clear the empty space
            n = n.split() # ["5","ayam goreng"] / ["4", "nasi lemak"]
            for x in range(len(n)):
                if x == 0: #round 1 just get the number/digit
                    quantity = eval(n[x])
                else:
                    food += f" {n[x]}" # round2 get the food name and add into the food variable
            else:
                customer.shop.add_order_list(food.strip(), quantity, customer.delv)
    except:
        print("Please input correct format ya~")
        receive_order()

# when user response is buy
def buy():
    customer.get_delivery()
    print("Rex Bot: Okay sir, may I know which food do you want to order. *(5 ayam goreng, 4 nasi lemak)")
    receive_order()
    customer.get_info()

    print("Rex Bot: OK sir. Thank you for your order. Let me do the order confirmation with you.")
    response = conform_order(customer.shop.order_list)
    if response == None:
        response="May I know which store are you going to order? We are having Malay stall, Mamak stall, Beverage stall, Korean stall and Japanese stall."
    return response

# let user to conform their order
def conform_order(order_list):
    if order_list:
        print('*' * 17)
        print("* {0:^8s} *".format("Order Confirm"))
        print('*' * 17)
        num = 1

        for i in order_list:
            print("{0:d}. {1:<25s}×{2:^5d}".format(num, i.title(), order_list[i]))
            num += 1
        else:
            print("\nRex Bot: Is everything correct?")
    else:
        print("Rex Bot: You have not order food in this stall. Is everything correct?")

    user_input = input()
    if user_input != "yes":
        print("Rex Bot: Do you want to add order or remove order?")
        user_input = input()
        if user_input == "add order":
            print("Rex Bot: Which food do you want to add? *(5 ayam goreng, 4 nasi lemak)")
            receive_order()
        elif user_input == "remove order":
            print("Rex Bot: Which food do you want to remove? *(5 ayam goreng, 4 nasi lemak)")
            list = input()
            list = list.split(",")
            for i in range(len(list)):
                food = ""
                n = list[i].strip()
                n = n.split()
                for x in range(len(n)):
                    if x == 0:
                        quantity = eval(n[x])
                    else:
                        food += f" {n[x]}"
                else:
                    customer.shop.remove_food(food.strip(), quantity)

        conform_order(order_list)

    else:
        print("Rex Bot: Do you want to see other stall?")
        user_input = input()
        if user_input == "yes":
            return "May I know which store are you going to order? We are having Malay stall, Mamak stall, Beverage stall, Korean stall and Japanese stall."
        else:
            customer.get_shop_list()
            calculate(customer.shop_list)
            pop_image("Rex_Bot_Tq.png", "Thank you!!")
            return "Thank you!!"


def bank_payment():
    print("Choose the bank you wish to use for online transfer:")
    print("1. CIMB Bank Berhad\n2. Maybank Berhad\n3. Public Bank\n4. Hong Leong Bank Berhad")
    num = input()
    print("Proceed to payment...")
    time.sleep(2)
    print("Receiving the payment...")
    time.sleep(2)
    print("The payment is succeed")


def tng_payment():
    print("Please scan the qr code below for payment.")
    pop_image("touchngo (QR).png", "QR code payment")
    print("Receiving the payment...")
    time.sleep(2)
    print("The payment is succeed")


def info_confirm():
    print("Rex bot: Please confirm the information below is true:")
    print("1. Name: {0:s}".format(customer.name))
    print("2. Phone no.: {0:s}".format(customer.phone))
    print("3. Address: {0:s}".format(customer.add))
    ans = str(input())

    if ans == "yes":
        pass

    elif ans == "no":
        print("Rex bot: Which part of the information is incorrect? (e.g. 1/2/3)")
        reply = int(input())
        print("Rex bot: Please enter your correct information.")
        info = str(input())

        if reply == 1:
            customer.name = info
            info_confirm()

        elif reply == 2:
            customer.phone = info
            info_confirm()

        elif reply == 3:
            customer.add = info
            info_confirm()

        else:
            print("Rex bot: Error input, please follow the true format.")
            info_confirm()


def calculate(shop):
    customer.get_time()
    customer.get_card()
    customer.get_reminder()
    delivery_fee = 5
    total = 0

    print('*' * 12)
    print("* Payment  *")
    print('*' * 12)
    print("# " * 34)
    print("#{0:^25s}#{1:^14s}#{2:^10s}#{3:^14s}".format("Name", "Price", "Quantity", "PxQ"))
    print("# " * 34)

    for x in range(len(shop)):
        print(" <<{0:^21s}>> ".format(shop[x].name))
        for i in shop[x].order_list:
            # Price=price*quantity
            Price = float(shop[x].menu[i].price) * shop[x].menu[i].quantity
            print(" {0:<25s} {1:^14.2f} {2:^10d} {3:^14.2f}".format(shop[x].menu[i].name, float(shop[x].menu[i].price),
                                                                    shop[x].menu[i].quantity, Price))
            # Cal total price of the whole order
            total += Price
        else:
            print()

    if customer.card == "yes":
        total = total + delivery_fee
        discount = total * 0.05
        Total = total - discount
        print("# " * 34)
        print("#{0:<51s}#  RM{1:^9s}#".format(" 1. Delivery fee", "5.00"))
        print("#{0:<51s}# -RM{1:^9.2f}#".format(" 2. Student/Staff (-5%)", discount))
        print("#{0:^25s} {1:^14s}#{2:^10s}# RM{3:^10.2f}#".format("", "", "Total", Total))
        print("# " * 34)

    elif customer.card == "no":
        total = total + delivery_fee
        print("# " * 34)
        print("#{0:<51s}#  RM{1:^9s}#".format(" 1. Delivery fee", "5.00"))
        print("#{0:^25s} {1:^14s}#{2:^10s}# RM{3:^10.2f}#".format("", "", "Total", total))
        print("# " * 34)

    if customer.delv == "yes":
        info_confirm()
        if customer.time == "now":
            print("Rex bot: Your food will be prepared and delivered within 15 minutes")
        else:
            print("Rex bot: Your food will be prepared and delivered at {0:s}.".format(customer.time))

    elif customer.delv == "no":
        customer.add="-"
        info_confirm()
        if customer.time == "now":
            print("Rex bot: Your food will be prepare now. Please pick up your food at the counter after 15 minutes.")
        else:
            print("Rex bot: Your food will be prepared in {0:s}. Please pick up your food at the counter.".format(customer.time))

    # Ask for payment method
    if customer.delv == "yes":
        print("Choose the method you wish to do payment:")
        print("1. Online Banking\n2. Touch N Go")
        user_input = int(input())
        print(user_input)

        if user_input == 1:
            bank_payment()

        elif user_input == 2:
            tng_payment()

    elif customer.delv == "no":
        print("Choose the method you wish to do payment:")
        print("1. Online Banking\n2. Touch N Go\n3. Pay at counter")
        user_input = int(input())

        if user_input == 1:
            bank_payment()

        elif user_input == 2:
            tng_payment()

        elif user_input == 3:
            print("Your order list number is {0:d}".format(random.randint(100, 999)))
            print("Please make your payment at the counter with the given order list number.")


def pop_image(image="Rex_Bot_Logo.png", image_name='Rex Bot Logo'):
    print(image)
    path = rf'{image}'  # test

    # Using cv2.imread() method
    # Using 0 to read image in grayscale mode
    # Using 1 to read image in colour mode
    img = cv2.imread(path, 1)

    # Displaying the image
    cv2.imshow(image_name, img)

    cv2.waitKey(0)
    # and finally destroy/close all open windows
    cv2.destroyAllWindows()


# Function to return a random greeting response to a users greeting
def detect_response(text):
    # Convert the text to be all lowercase
    text = text.lower()
    # Keyword Matching

    # normal list
    normal = ["question", "shop", "thanks", "away", "workinghour"]

    # If user's input, return a randomly chosen  response
    for tag in data.intents:
        if text in tag["patterns"]:
            tag_name = tag["tag"]

            if tag_name in normal:
                return random.choice(tag["responses"])
            # info
            elif tag_name == "greeting":
                print("Rex Bot: " + random.choice(tag["responses"]))
                user_input = input()
                customer.surname = user_input
                return (f"Hi {customer.surname}, nice to meet you. How can I help you?")

            elif tag_name == "menu":
                text = text.split(" ")
                shop = eval(text[0])
                shop.print_menu()
                customer.shop = shop
                return random.choice(tag["responses"])
            elif tag_name == "buy":
                return buy()

    else:
        responses = ["Oops, I don't get it", "Oops, you got me! Unfortunately, I cannot understand the word"]
        return random.choice(responses)



# Start the chat
pop_image()
print("Rex Bot: I am Rex BOT to help you. I will answer your queries about A-05-03A. If you want to exit, please type Bye!")
exit_list = ['exit', 'bye', 'quit', 'break', "see ya", "cya", "see you later", "goodbye", "88", "have a nice day",
             "ok, thank you"]
customer = Customer()
while (True):
    user_input = input()
    if (user_input.lower() in exit_list):
        responses = ["Goodbye!", "Bye!!", " Hope to see you soon!", "Sad to see you go :(",
                     "Glad to help you! I'll be happy to help out if you need anything else.", "Chat with you later !"]
        customer.get_feedback()
        print("Rex Bot: " + random.choice(responses))
        break
    else:
        print("Rex Bot: " + detect_response(user_input))

pop_image("Rex_Bot_Bye.png", "Bye bye!")


