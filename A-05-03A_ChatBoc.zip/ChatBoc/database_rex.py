stall=["Malay","Mamak","Beverage","Korean","Japanese"]
#list of malay foods 
malay=[{"item":"Nasi lemak","price":"2.00","del_serv":"yes"},
       {"item":"Nasi goreng kampung","price":"6.00","del_serv":"yes"},
       {"item":"Nasi goreng tomyam","price":"6.50","del_serv":"yes"},
       {"item":"Nasi goreng ikan masin","price":"6.50","del_serv":"yes"},
       {"item":"Nasi goreng paprik","price":"7.00","del_serv":"yes"},
       {"item":"Nasi goreng USA","price":"7.00","del_serv":"yes"},
       {"item":"Nasi goreng pattaya","price":"7.00","del_serv":"yes"},
       {"item":"Nasi gorneg biasa","price":"5.00","del_serv":"yes"},
       {"item":"Ikan goreng","price":"3.50","del_serv":"yes"},
       {"item":"Ayam goreng","price":"3.00","del_serv":"yes"},
       {"item":"Satay","price":"1.20","del_serv":"yes"},
       {"item":"Kuih talam","price":"0.70","del_serv":"no"},
       {"item":"Kuih koci","price":"0.40","del_serv":"no"}]

#list of mamak foods
mamak=[{"item":"Roti canai","price":"1.20","del_serv":"no"},
       {"item":"Roti telur","price":"2.30","del_serv":"no"},
       {"item":"Roti cheese","price":"2.50","del_serv":"no"},
       {"item":"Roti boom","price":"2.20","del_serv":"no"},
       {"item":"Roti planta","price":"2.20","del_serv":"no"},
       {"item":"Roti susu","price":"2.20","del_serv":"no"},
       {"item":"Roti tisu","price":"3.20","del_serv":"no"},
       {"item":"Tosai","price":"1.20","del_serv":"no"},
       {"item":"Mee goreng","price":"5.00","del_serv":"yes"},
       {"item":"Maggi goreng","price":"5.00","del_serv":"yes"},
       {"item":"Maggi soup","price":"4.00","del_serv":"yes"},
       {"item":"Teh tarik ais","price":"2.20","del_serv":"no"},
       {"item":"Teh tarik panas","price":"1.80","del_serv":"no"},
       {"item":"Milo ais","price":"2.50","del_serv":"no"},
       {"item":"Milo panas","price":"2.20","del_serv":"no"},
       {"item":"Cincau","price":"2.50","del_serv":"no"},
       {"item":"Limau ais","price":"1.80","del_serv":"no"},
       {"item":"Limau panas","price":"1.50","del_serv":"no"},
       {"item":"Bandung ais","price":"2.00","del_serv":"no"}]

#list of beverage
beverage=[{"item":"Apple juice","price":"5.00","del_serv":"no"},
          {"item":"Orange juice","price":"5.00","del_serv":"no"},
          {"item":"Watermelon juice","price":"5.00","del_serv":"no"},
          {"item":"Cucumber juice","price":"5.00","del_serv":"no"},
          {"item":"Pineapple juice","price":"5.00","del_serv":"no"},
          {"item":"Carrot juice","price":"5.00","del_serv":"no"},
          {"item":"Espresso","price":"6.00","del_serv":"yes"},
          {"item":"Hot Americano","price":"7.00","del_serv":"yes"},
          {"item":"Iced Americano","price":"8.00","del_serv":"yes"},
          {"item":"Hot Latte","price":"9.00","del_serv":"yes"},
          {"item":"Iced Latte","price":"10.00","del_serv":"yes"},
          {"item":"Hot Cappuccino","price":"9.00","del_serv":"yes"},
          {"item":"Ice Cappuccino","price":"10.00","del_serv":"yes"},
          {"item":"Hot Mocha","price":"9.00","del_serv":"yes"},
          {"item":"Iced Mocha","price":"10.00","del_serv":"yes"}]

#list of Korean
Korean=[{"item":"Tteok","price":"2.00","del_serv":"yes"},
        {"item":"Kimchi","price":"4.00","del_serv":"yes"},
        {"item":"Gimbap","price":"4.50","del_serv":"yes"},
        {"item":"Tteokbokki","price":"5.00","del_serv":"yes"},
        {"item":"Hobakjuk","price":"6.00","del_serv":"yes"},
        {"item":"Ramyun","price":"6.50","del_serv":"yes"},
        {"item":"Kimchi Fried Rice","price":"7.00","del_serv":"yes"},
        {"item":"Bulgogi","price":"7.00","del_serv":"yes"},
        {"item":"Jjajangmyeon","price":"7.00","del_serv":"yes"},
        {"item":"Kongguksu","price":"7.50","del_serv":"yes"},
        {"item":"Japchae","price":"8.00","del_serv":"yes"},
        {"item":"Bulgogi with rice","price":"8.00","del_serv":"yes"},
        {"item":"Naengmyeon","price":"8.50","del_serv":"yes"},
        {"item":"Bibimbap","price":"9.00","del_serv":"yes"},
        {"item":"Sundubu Jjigae","price":"10.00","del_serv":"yes"}]

#list of Japanese
Japanese=[{"item":"Miso Soup","price":"1.50","del_serv":"yes"},
          {"item":"Chawanmushi","price":"1.50","del_serv":"yes"},
          {"item":"Gyoza","price":"5.00","del_serv":"yes"},
          {"item":"Tempura","price":"5.00","del_serv":"yes"},
          {"item":"Tamagoyaki","price":"1.50","del_serv":"yes"},
          {"item":"Teriyaki Chicken Bento","price":"9.00","del_serv":"yes"}]

intents=[ {"tag": "greeting",
         "patterns": ["hi", "hello", "how are you", "is anyone there", "good day", "whats up""howdy", "hey", "what's good","hey there"],
         "responses": ["Hello! Nice to meet you! May I get your name?", "Hi! Nice to meet you! May I get your name?",
                       "Good to see you, Sir, may I get your name?", "Hi there, may I get your name?", "Wassup bro, what's your name"]
           },
        {"tag": "question",
         "patterns": ["what do you do", "what can you offer", "how can you help me"],
         "responses": ["I can guide you to order the food from the cafeteria.  What do you need?"]
         },
        {"tag": "shop",
         "patterns": ["i want to buy something to eat", "can i get something to eat", "may i know which restaurant is available"],
         "responses": ["We are having :\n\t\t 1.Malay stall\n\t\t 2.Mamak stall\n\t\t 3.Beverage stall\n\t\t 4.Korean stall\n\t\t 5.Japanese stall.\n\t\t May I know which stall are you interested?"]
         },
        {"tag": "workinghour",
         "patterns": ["when are you guys open", "what are your working hours", "may I know your operation hours","Do you operate now"],
         "responses": ["The stalls are open from 10.30a.m. - 6.30p.m. (Monday - Saturday). But I am always be here to help you."]
         },
        {"tag": "buy",
         "patterns": ["Yes, I want to buy the food from this restaurant", "yes, i am interested on it",
                      " Yes, I want to order the food"],
         "responses": ["Okay, may I know which food do you want to order"]
         },
        {"tag": "menu",
         "patterns": ["malay stall", "mamak stall", "beverage stall", "korean stall", "japanese stall"],
         "responses": ["So, do you want to buy the food from this restaurant?"]
         },
        {"tag": "nobuy",
         "patterns": ["no, I am not interested in it", "no, I don't want to buy food from this restaurant"],
         "responses": ["Ok sir, do you want to change the restaurant?"]
         },
        {"tag": "away",
         "patterns": ["i will come back later" , " I will be right back"],
         "responses": ["No problem. We will help you when you need us. Thank you for your time"]
         },
        {"tag" : "time",
         "patterns" : ["time"],
         "responses" : ["Ok sir. We will prepare the food on time. May I know do you want to pick up or delivery the food?"],
        },
        {"tag": "away",
         "patterns": ["I will come back later", " I will be right back"],
         "responses": ["No problem. We will help you when you need us. Thank you for your time"]
         },
        {"tag": "thanks",
         "patterns": ["thanks", "thank", "thank you", "that's helpful", "awesome, thanks", "thanks for helping me"],
         "responses": ["Happy to help!", "It's my pleasure!", "You are welcome"]
         },
          {"tag": "completepayment",
           "patterns": ["ok, I have made the payment"],
           "responses": ["OK sir. Thank you for your purchase. :)"],
           },
          {"tag": "thanks",
           "patterns": ["thanks", "thank", "thank you", "that's helpful", "awesome, thanks", "thanks for helping me"],
           "responses": ["Happy to help you!", "It's my pleasure!", "You are welcome"],
           }
    ]




